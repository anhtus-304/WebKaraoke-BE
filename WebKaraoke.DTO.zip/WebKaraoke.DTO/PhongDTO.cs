namespace WebKaraoke.DTO
{
    public class PhongDTO
    {
        public int PhongID { get; set; }
        public string TenPhong { get; set; } = string.Empty;
        public string LoaiPhong { get; set; } = string.Empty;
        public decimal GiaGio { get; set; }
        public string TrangThai { get; set; } = string.Empty;
    }

    public class PhongCreateDTO
    {
        public string TenPhong { get; set; } = string.Empty;
        public string LoaiPhong { get; set; } = string.Empty;
        public decimal GiaGio { get; set; }
        public string TrangThai { get; set; } = "Trong";
    }

    public class PhongUpdateDTO
    {
        public string TenPhong { get; set; } = string.Empty;
        public string LoaiPhong { get; set; } = string.Empty;
        public decimal GiaGio { get; set; }
        public string TrangThai { get; set; } = string.Empty;
    }
}