using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebKaraoke.Business.Interfaces;
using WebKaraoke.DTO;

namespace WebKaraoke.API.Controllers
{
    [ApiController]
    [Route("api/v1/[controller]")]
    [Authorize(Roles = "Admin, NhanVien")]
    public class NhanVienController : ControllerBase
    {
        private readonly INhanVienService _service;

        public NhanVienController(INhanVienService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var list = await _service.GetAllNhanViensAsync();
            return Ok(list);
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var result = await _service.GetNhanVienByIdAsync(id);
            return result is null ? NotFound() : Ok(result);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] NhanVienCreateDTO dto)
        {
            var success = await _service.CreateNhanVienAsync(dto);
            return success ? Ok(new { message = "Tạo nhân viên thành công" }) : BadRequest();
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, [FromBody] NhanVienUpdateDTO dto)
        {
            var success = await _service.UpdateNhanVienAsync(id, dto);
            return success ? Ok(new { message = "Cập nhật thành công" }) : NotFound();
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var success = await _service.DeleteNhanVienAsync(id);
            return success ? Ok(new { message = "Xóa thành công" }) : NotFound();
        }
    }
}
